import { Canvas } from "@react-three/fiber";
import { OrbitControls, Stars } from "@react-three/drei";
import { Suspense, useState, useEffect } from "react";
import { Html } from "@react-three/drei";
import { useThree } from "@react-three/fiber";

const userData = [];
const musicData = {}; // store comments and likes per track

function MobileController({ onMove }) {
  return (
    <div className="fixed bottom-6 left-6 z-50 flex gap-4">
      <button onTouchStart={() => onMove('left')} className="w-12 h-12 bg-indigo-600 rounded-full">⬅️</button>
      <button onTouchStart={() => onMove('right')} className="w-12 h-12 bg-indigo-600 rounded-full">➡️</button>
      <button onTouchStart={() => onMove('up')} className="w-12 h-12 bg-indigo-600 rounded-full">⬆️</button>
      <button onTouchStart={() => onMove('down')} className="w-12 h-12 bg-indigo-600 rounded-full">⬇️</button>
    </div>
  );
}

export default function App() {
  const [currentTrack, setCurrentTrack] = useState(null);
  const [authOpen, setAuthOpen] = useState(true);
  const [adminOpen, setAdminOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [users, setUsers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [uploadedTracks, setUploadedTracks] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [userPosition, setUserPosition] = useState([0, 1, 0]);

  const handleRegister = user => {
    setUsers(prev => [...prev, user]);
  };

  const handleLogin = user => {
    setCurrentUser(user);
  };

  const handleLike = (trackUrl) => {
    musicData[trackUrl] = musicData[trackUrl] || { likes: 0, comments: [] };
    musicData[trackUrl].likes++;
  };

  const handleComment = (trackUrl, newComment) => {
    musicData[trackUrl] = musicData[trackUrl] || { likes: 0, comments: [] };
    musicData[trackUrl].comments.push(`${currentUser.username}: ${newComment}`);
  };

  const handleUpload = async (e) => {
    const file = e.target.files[0];
    if (!file || !currentUser) return;
    const formData = new FormData();
    formData.append('file', file);
    formData.append('uploader', currentUser.username);

    const res = await fetch('/api/upload', {
      method: 'POST',
      body: formData
    });
    const result = await res.json();
    if (result.success) {
      setUploadedTracks(prev => [...prev, result.track]);
      const userIndex = userData.findIndex(u => u.username === currentUser.username);
      if (userIndex > -1) userData[userIndex].uploads = (userData[userIndex].uploads || 0) + 1;
    }
  };

  const sortedFilteredTracks = uploadedTracks
    .filter(track => track.name.toLowerCase().includes(searchQuery.toLowerCase()))
    .sort((a, b) => (musicData[b.url]?.likes || 0) - (musicData[a.url]?.likes || 0));

  const moveOrb = (direction) => {
    const [x, y, z] = userPosition;
    switch (direction) {
      case 'left': setUserPosition([x - 1, y, z]); break;
      case 'right': setUserPosition([x + 1, y, z]); break;
      case 'up': setUserPosition([x, y, z - 1]); break;
      case 'down': setUserPosition([x, y, z + 1]); break;
    }
  };

  return (
    <div className="w-full h-screen bg-black touch-none">
      {authOpen && <AuthPanel onClose={() => setAuthOpen(false)} onRegister={handleRegister} onLogin={handleLogin} />}
      {adminOpen && <AdminPanel users={users} />}
      {profileOpen && currentUser && <UserProfile user={currentUser} onClose={() => setProfileOpen(false)} />}

      <Canvas camera={{ position: [0, 2, 10], fov: 60 }}>
        <ambientLight intensity={0.5} />
        <pointLight position={[10, 10, 10]} />
        <Stars radius={100} depth={50} count={5000} factor={4} saturation={0} fade />
        <Suspense fallback={null}>
          <GlowingOrb position={userPosition} />
          {sortedFilteredTracks.map((track, idx) => (
            <MusicPanel
              key={idx}
              position={[Math.cos(idx) * 6, 1, Math.sin(idx) * 6]}
              trackName={track.name}
              trackSrc={track.url}
              onClick={() => setCurrentTrack(track.url)}
              onLike={() => handleLike(track.url)}
              onComment={(comment) => handleComment(track.url, comment)}
              likes={musicData[track.url]?.likes || 0}
              comments={musicData[track.url]?.comments || []}
            />
          ))}
          {users.map((u, idx) => (
            <SocialUser key={u.username} username={u.username} position={[Math.sin(idx) * 4, 1, Math.cos(idx) * 4]} />
          ))}
        </Suspense>
        <OrbitControls enableZoom={false} />
      </Canvas>

      <MobileController onMove={moveOrb} />

      <div className="absolute top-4 right-4 text-white text-sm space-y-2 w-60">
        <p>Theme: Inspired by Pegasus – the cosmic winged horse</p>
        <input
          type="text"
          placeholder="Search tracks..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full px-2 py-1 text-xs rounded bg-gray-700 text-white placeholder-gray-400"
        />
        <button onClick={() => setAuthOpen(true)} className="bg-indigo-700 px-3 py-1 rounded hover:bg-indigo-600 text-xs w-full">Login/Register</button>
        <button onClick={() => setAdminOpen(true)} className="bg-red-600 px-3 py-1 rounded hover:bg-red-500 text-xs w-full">Admin Panel</button>
        {currentUser && (
          <>
            <button onClick={() => setProfileOpen(true)} className="bg-gray-700 px-3 py-1 rounded hover:bg-gray-600 text-xs w-full">My Profile</button>
            <label className="block mt-2">
              <span className="text-xs">Upload Music</span>
              <input type="file" accept="audio/mp3" onChange={handleUpload} className="text-xs mt-1" />
            </label>
          </>
        )}
      </div>

      {currentTrack && (
        <audio autoPlay controls className="absolute bottom-4 left-4">
          <source src={currentTrack} type="audio/mp3" />
          Your browser does not support the audio element.
        </audio>
      )}
    </div>
  );
}
